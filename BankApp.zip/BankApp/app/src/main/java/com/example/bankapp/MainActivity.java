package com.example.bankapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button withdraw, deposite;
    EditText ac_no,Amt,pin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        withdraw = findViewById(R.id.btnWithdraw);
        deposite = findViewById(R.id.btnDeposite);
        ac_no = findViewById(R.id.text1);
        Amt = findViewById(R.id.edit_text2);
        pin = findViewById(R.id.edit_text3);

        withdraw.setOnClickListener(v -> {

            String str1= Amt.getText().toString();

           final Intent intent = new Intent(getApplicationContext(),SecondActivity.class);

            intent.putExtra("message_key1",str1);

            startActivity(intent);
        });

        deposite.setOnClickListener(v -> {

            String str1 =Amt.getText().toString();

        final Intent intent = new Intent(getApplicationContext(),SecondActivity2.class);

        intent.putExtra("message_key1",str1);

        startActivity(intent);

        });

    }
}