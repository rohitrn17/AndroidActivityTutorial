package com.example.bankapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity2 extends AppCompatActivity {
    TextView text1;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second2);

        text1 = findViewById(R.id.text_view);

        Intent intent = getIntent();

        String str1 = intent.getStringExtra("message_key1");

        text1.setText(str1);

    }
}
