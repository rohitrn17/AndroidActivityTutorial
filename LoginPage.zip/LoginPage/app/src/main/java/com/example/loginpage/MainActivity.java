package com.example.loginpage;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button login;
    EditText username, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        login = (Button) findViewById(R.id.login);
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });

    }
    public void login(){
        String user = username.getText().toString().trim();
        String pass = password.getText().toString().trim();
        if(user.equals("admin")&&pass.equals("admin"))
        {
            Toast.makeText(this,"Successful login",Toast.LENGTH_LONG).show();
            Intent intent =  new Intent(MainActivity.this,User.class);
            startActivity(intent);
        }else
        {
            Toast.makeText(this,"username and password are not matched",Toast.LENGTH_LONG).show();
        }
    }
}