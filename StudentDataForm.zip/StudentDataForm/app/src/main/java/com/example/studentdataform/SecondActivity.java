package com.example.studentdataform;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    TextView text_view1,text_view2,text_view3,text_view4,text_view5,text_view6;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        text_view1 =findViewById(R.id.text_view1);
        text_view2 =findViewById(R.id.text_view2);
        text_view3 =findViewById(R.id.text_view3);
        text_view4 =findViewById(R.id.text4);
        text_view5 =findViewById(R.id.text_view5);
        text_view6 =findViewById(R.id.text_view6);

        Intent intent = getIntent();

        String str1 = intent.getStringExtra("message_key1");
        String str2 = intent.getStringExtra("message_key2");
        String str3 = intent.getStringExtra("message_key3");
        String str4 = intent.getStringExtra("message_key4");
        String str5 = intent.getStringExtra("message_key5");
        String str6 = intent.getStringExtra("message_key6");



        text_view1.setText(str1);
        text_view2.setText(str2);
        text_view3.setText(str3);
        text_view4.setText(str4);
        text_view5.setText(str5);
        text_view6.setText(str6);

    }
}
