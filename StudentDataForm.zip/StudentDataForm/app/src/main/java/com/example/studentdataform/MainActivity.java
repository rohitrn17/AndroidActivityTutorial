package com.example.studentdataform;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button next;
    EditText text1,text2,text3,text4,text5,text6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        next = findViewById(R.id.btnNext);
        text1 = findViewById(R.id.edit_text1);
        text2 = findViewById(R.id.edit_text2);
        text3 = findViewById(R.id.edit_text3);
        text4 = findViewById(R.id.dob);
        text5 = findViewById(R.id.address);
        text6 = findViewById(R.id.email);

        next.setOnClickListener(v -> {

            String str1 = text1.getText().toString();
            String str2 = text2.getText().toString();
            String str3 = text3.getText().toString();
            String str4 = text4.getText().toString();
            String str5 = text5.getText().toString();
            String str6 = text6.getText().toString();

            Intent intent = new Intent(getApplicationContext(),SecondActivity.class);

            intent.putExtra("message_key1",str1);
            intent.putExtra("message_key2",str2);
            intent.putExtra("message_key3",str3);
            intent.putExtra("message_key4",str4);
            intent.putExtra("message_key5",str5);
            intent.putExtra("message_key6",str6);

            startActivity(intent);
        });
    }
}