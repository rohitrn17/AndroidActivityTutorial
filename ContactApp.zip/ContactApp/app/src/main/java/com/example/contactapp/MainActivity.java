package com.example.contactapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button save;
    EditText text1,text2,text3,text4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        save = findViewById(R.id.btnSave);
        text1 = findViewById(R.id.edit_text1);
        text2 = findViewById(R.id.edit_text2);
        text3 = findViewById(R.id.edit_text3);
        text4 = findViewById(R.id.edit_text4);

        save.setOnClickListener(v -> {

            String str1 = text1.getText().toString();
            String str2 = text2.getText().toString();
            String str3 = text3.getText().toString();
            String str4 = text4.getText().toString();

            Intent intent = new Intent(getApplicationContext(),SecondActivity.class);

            intent.putExtra("message_key1",str1);
            intent.putExtra("message_key2",str2);
            intent.putExtra("message_key3",str3);
            intent.putExtra("message_key4",str4);

            startActivity(intent);

        });

    }
}